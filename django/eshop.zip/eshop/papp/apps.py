from django.apps import AppConfig


class PappConfig(AppConfig):
    name = 'papp'
